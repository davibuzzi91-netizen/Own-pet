# Own Pet

Aplicativo Android nativo para pet flutuante sobre outros aplicativos.

## Estado atual

Implementados: seleção dos três personagens, persistência do personagem, permissão de sobreposição, serviço em primeiro plano, janela flutuante arrastável, movimento básico, menu e temporizadores das habilidades.

Referências recebidas e preservadas em `www/assets/references/`: Eclipse, Gourdy e Soulvester. Elas são referências visuais fornecidas pelo usuário; ainda não foram recortadas nem convertidas em sprites finais do aplicativo.

## Compilação

Abra no Android Studio e execute `./gradlew assembleDebug`. O APK esperado será `app/build/outputs/apk/debug/app-debug.apk`.
