package com.ownpet.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.concurrent.atomic.AtomicBoolean

class PetService : Service() {
    private lateinit var wm: WindowManager; private var pet: TextView?=null; private var menu: LinearLayout?=null; private val stopped=AtomicBoolean(false); private var activePet="Eclipse"; private val handler=Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?)=null
    override fun onStartCommand(i: Intent?, flags:Int, id:Int):Int { activePet=i?.getStringExtra("pet")?:activePet; if(pet==null) setup(); return START_NOT_STICKY }
    private fun setup(){
        createChannel(); startForeground(7,Notification.Builder(this,"own_pet").setContentTitle("Own Pet ativo").setContentText(activePet).setSmallIcon(android.R.drawable.ic_menu_myplaces).build())
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        pet=TextView(this).apply { text="[$activePet]\nassets pendentes"; textSize=13f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=GradientDrawable().apply{cornerRadius=28f;setColor(Color.rgb(80,45,120))}; setOnTouchListener(TouchHandler()); setOnClickListener{showMenu()} }
        val p=WindowManager.LayoutParams(150,120,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, -3); p.gravity=Gravity.TOP or Gravity.START; p.x=30;p.y=220; wm.addView(pet,p); walk(p)
    }
    private fun walk(p:WindowManager.LayoutParams){ var dx=3; handler.post(object:Runnable{override fun run(){if(stopped.get()||pet==null)return; p.x+=dx; if(p.x<0||p.x>wm.currentWindowMetrics.bounds.width()-160)dx=-dx; wm.updateViewLayout(pet,p);handler.postDelayed(this,40)}}) }
    private fun showMenu(){ if(menu!=null)return; menu=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE); listOf("Carinho","Comida","Dormir","Habilidade especial","Fechar").forEach{n->addView(Button(this@PetService).apply{text=n;setOnClickListener{if(n=="Habilidade especial")special(); if(n=="Fechar"){menu?.let{wm.removeView(it)};menu=null}}})}}; val p=WindowManager.LayoutParams(260,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,-3);p.gravity=Gravity.TOP or Gravity.START;p.x=20;p.y=350;wm.addView(menu,p) }
    private fun special(){ val duration=if(activePet=="Soulvester")15000L else 10000L; pet?.text=when(activePet){"Gourdy"->"Gourdy\nDoces ou travessuras!";"Soulvester"->"Soulvester\nGUARDA";else->"Eclipse\nLOBO"}; handler.postDelayed({pet?.text="[$activePet]\nassets pendentes"},duration) }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("own_pet","Own Pet",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy(){stopped.set(true);handler.removeCallbacksAndMessages(null);pet?.let{if(::wm.isInitialized)wm.removeView(it)};menu?.let{if(::wm.isInitialized)wm.removeView(it)};pet=null;menu=null;super.onDestroy()}
    private inner class TouchHandler:View.OnTouchListener{var sx=0f;var sy=0f;var px=0;var py=0;override fun onTouch(v:View,e:android.view.MotionEvent):Boolean{val lp=v.layoutParams as WindowManager.LayoutParams;when(e.action){0->{sx=e.rawX;sy=e.rawY;px=lp.x;py=lp.y};2->{lp.x=px+(e.rawX-sx).toInt();lp.y=py+(e.rawY-sy).toInt();wm.updateViewLayout(v,lp)}};return true}}
}
