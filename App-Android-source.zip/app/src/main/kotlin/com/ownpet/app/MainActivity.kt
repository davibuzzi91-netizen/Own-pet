package com.ownpet.app

import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("own_pet", MODE_PRIVATE) }
    private var selected: String get() = prefs.getString("pet", "Eclipse")!!; set(v) { prefs.edit().putString("pet", v).apply() }
    override fun onCreate(state: Bundle?) { super.onCreate(state); render() }
    private fun render() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,40,32,32); gravity=Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text="Own Pet"; textSize=30f; setTextColor(Color.rgb(50,30,80)); gravity=Gravity.CENTER; setPadding(0,0,0,28) })
        root.addView(TextView(this).apply { text="Escolha seu personagem"; textSize=18f })
        val group=RadioGroup(this).apply { orientation=RadioGroup.VERTICAL; setPadding(0,20,0,20) }
        listOf("Eclipse","Gourdy","Soulvester").forEach { name -> group.addView(RadioButton(this).apply { text=name; textSize=18f; isChecked=name==selected; setOnClickListener { selected=name } }) }
        root.addView(group)
        val permission=TextView(this).apply { textSize=15f; setPadding(0,12,0,12) }
        root.addView(permission)
        val allow=Button(this).apply { text="Permitir sobreposição"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }
        root.addView(allow)
        val start=Button(this).apply { text="Iniciar pet"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) { Toast.makeText(context,"Conceda a permissão de sobreposição primeiro.",Toast.LENGTH_LONG).show(); return@setOnClickListener }; val i=Intent(this@MainActivity,PetService::class.java); i.putExtra("pet",selected); startForegroundService(i) } }
        root.addView(start)
        root.addView(Button(this).apply { text="Encerrar pet"; setOnClickListener { stopService(Intent(this@MainActivity,PetService::class.java)) } })
        permission.text=if(Settings.canDrawOverlays(this)) "Sobreposição: permitida" else "Sobreposição: não permitida"
        setContentView(root)
    }
    override fun onResume(){ super.onResume(); if(::rootReady.isInitialized) render() }
    private lateinit var rootReady: Unit
}
