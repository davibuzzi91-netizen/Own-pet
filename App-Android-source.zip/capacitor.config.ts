import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.ownpet.app', appName: 'Own Pet', webDir: 'www' };
export default config;
